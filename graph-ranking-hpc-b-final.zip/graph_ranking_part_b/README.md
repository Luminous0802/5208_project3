# Graph Ranking — Part B

Hybrid MPI–OpenMP PageRank: implementation, performance experiments, and analysis.

## Contents

- `src/`: C++ implementation (V2/V3), graph generator and graph statistics.
- `baseline_a/`: A's serial and pure-MPI reference implementations.
- `scripts/`: original Vanda PBS jobs, benchmark runner and experiment configuration files.
- `results/`: original archived experiment outputs. **Only four official jobs are included in the analysis:** B1 `1515568`, B2 `1515643`, B3 `1515702`, B4 `1515718`. Other directories are retained as provenance, not used for reporting.
- `analysis/plot_results.py`: full reproducible validation, aggregation and plotting code.
- `tables/`: generated configuration summaries, data checks and paired speedup tables.
- `figures/`: 12 publication-style figures in PNG (260 dpi) and vector PDF formats.
- `report/`: report draft and figure guide.

## Reproduce analysis on macOS

```bash
cd graph_ranking_part_b
python -m pip install -r requirements.txt
python analysis/plot_results.py
open figures
```

No MPI, Vanda access, or graph reconstruction is needed for plotting. The script asserts 345 valid official measurements, five repeats per configuration, fixed 50 iterations, and rank-sum tolerance. It does not claim to validate full PageRank vectors on all large graphs.

## Experimental interpretation

- Time values represent 50 PageRank iterations unless explicitly labeled `end-to-end`.
- `compute_s`, `allreduce_s`, and `allgatherv_s` are maxima over MPI ranks and **must not be summed or stacked**.
- B4 speedup pairs V2 and V3 **within the same graph seed and MPI/OpenMP layout**; the range across three seeds is descriptive, not a confidence interval.
- A's MPI sparsity analysis is separate. Pure-MPI 256-core scaling and GPU tests are whole-team requirements, not covered by this Part B archive.
- B4 generated graph edge lists were kept on Vanda scratch and are not included. Generator source, graph parameters, seeds and output hashes remain available.

## Source and benchmark provenance

Vanda compiled binaries, original CSV logs and metadata were backed up on 2026-11-04. Initial unsuccessful runs and runs with incorrect MPI process binding are retained under separate job IDs and intentionally excluded from all official figures.
